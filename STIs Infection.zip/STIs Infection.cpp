#include <iostream>

using namespace std;
 
 void name(){
 	string firstname,secondname,lastname;
 	cout<<"First Name\n";
 	cin>>firstname;
 	cout<<"Second Name\n";
 	cin>>secondname;
 	cout<<"Last Name\n";
 	cin>>lastname;
 	string birthday;
 	string emailaddress;
 	cout<<"Date of Birth\n";
 	cin>>birthday;
	 int year_of_birthday;
	int current_year;
		cout<<"Year of Birth:";
	cin>>year_of_birthday;
	cout<<"Current year:";
	cin>>current_year; 	
 	cout<<"Email Address\n";
 	cin>>emailaddress;
 	string password,confirmpassword;
 	cout<<"Enter Pasword\n";
 	cin>>password;
 	cout<<"Confirm Password\n";
 	cin>>confirmpassword;
 	while(password !=confirmpassword){
 		cout<<"Your password is incorrect Enter Password\n";
 		cin>>confirmpassword;
 		
 	}

 		cout<<"Name:" + firstname + " " + secondname + " "+ lastname<<endl;
	cout<<"Email Address:" + emailaddress<<endl;
	cout<<"Date of Birth:" + birthday<<endl;
	cout<<"Age:" << current_year - year_of_birthday<<endl;
	cout<<"Password:" + confirmpassword <<endl;
	cout<<"\n";
cout<<"Enter 1 and receive your Verification code\n";
short num1;
cin>>num1;
while (num1!=1){
	cout<<"Enter 1 to receive your Two-step Verification code\n";
	cin>>num1;
}
if (num1==1){
	cout<<"ABYO32029\n";
}


		
	

}
 void sick(){
 	    
  string sick1;
  			cout<<"Make sure that you experience this symptons before the system check the infections"<<endl;
cout<<"Do you see this symptoms\n";
 cout<<"Yes/No\n";
 cin>>sick1;
 if(sick1=="Yes"||sick1=="yes"||sick1=="YES"){
 	
 cout<<"YOU HAVE TESTED Sphylis Infection:"<<endl;
   cout<<"Take this medicine for treatment"<<endl;
   cout<<"1.Ceftriaxone(Injection)"<<endl;
   cout<<"2.Azithromycin(oral pill)"<<endl; 
   cout<<"3.Doxcycline(oral pill)"<<endl;

}
else{
	cout<<"Then you have not tested any of the  Infection try again when you see this symptoms GOOD BYE"<<endl;
}  
	
}
 void sick2(){
 	 	    
  string sick1;
  			cout<<"Make sure that you experience this symptons before the system check the infections"<<endl;
cout<<"Do you see this symptoms\n";
 cout<<"Yes/No\n";
 cin>>sick1;
 if(sick1=="Yes"||sick1=="yes"||sick1=="YES"){
 	
 cout<<"YOU HAVE TESTED Gonorrhea Infection:"<<endl;
   cout<<"Take this medicine for treatment"<<endl;
   cout<<"1.Ceftriaxone(Injection)"<<endl;
   cout<<"2.Azithromycin(oral pill)"<<endl; 
   cout<<"3.Doxcycline(oral pill)"<<endl;

}
	
else{
 	cout<<"Then you have not tested any of the  Infection try again when you see this symptoms GOOD BYE"<<endl;
}
}

 void sick3(){
 	    
  string sick1;
  			cout<<"Make sure that you experience this symptons before the system check the infections"<<endl;
cout<<"Do you see this symptoms\n";
 cout<<"Yes/No\n";
 cin>>sick1;
 if(sick1=="Yes"||sick1=="yes"||sick1=="YES"){
 	
 cout<<"YOU HAVE TESTED Chlaymydia Infection:"<<endl;
   cout<<"Take this medicine for treatment"<<endl;
   cout<<"1.Ceftriaxone(Injection)"<<endl;
   cout<<"2.Azithromycin(oral pill)"<<endl; 
   cout<<"3.Doxcycline(oral pill)"<<endl;

}
	
else{
cout<<"Then you have not tested any of the  Infection try again when you see this symptoms GOOD BYE"<<endl; 
}
 
}
void symptoms(){
	cout<<"1.Gonorrhoea\n";
	cout<<"2.Syphilis\n";
	cout<<"3.Chlaymydia\n";
	
}
void theo(){
	int option;
	cin>> option;
	if(option==1){
		sick();
	}
	else if(option==2){
		sick2();
	}
	else if(option==3){
	sick3();
}
}
void list(){

		cout<<" "<<endl;
	cout<<"Option 1\n";
	cout<<"1.Painless sore on the genitals"<<endl;
	cout<<"2.Vaginal discharge or wart-like growths on genitals"<<endl;
	cout<<"3.General feeling of discomfort"<<endl;
	cout<<"4.rashes"<<endl;
	cout<<"5.small bump"<<endl;
	cout<<"6.Anal itching,"<<endl;
	cout<<"7.sore throat"<<endl; 
	cout<<"8.Swollen lymph nodes"<<endl;
	cout<<"9.Fatigue"<<endl;
	cout<<" "<<endl;
		cout<<"Option 2\n";
	cout<<"1.Pain urination"<<endl;
	cout<<"2.Aborminal vaginal or penile discharge"<<endl;
	cout<<"3. Pain or discomfort during sexual intercouse"<<endl;
	cout<<"4.Bleeding during sex"<<endl;
	cout<<"5. lower abdominal pain"<<endl;
	cout<<"6.Musle or joint pain"<<endl; 
	cout<<"7.sore throat (if gonorrhea is contracted orally) "<<endl;
	cout<<"8.Anal itching, discharge or bleeding (if gonorrhea is contracted orally) "<<endl;
	cout<<"9.Swollen testicles"<<endl;    
 	cout<<" "<<endl;
 	cout<<"Option 3\n";
 		cout<<"1.Pain urination"<<endl;
	cout<<"2.Aborminal vaginal or penile discharge"<<endl;
	cout<<"3. Pain or discomfort during sexual intercouse"<<endl;
	cout<<"4.Bleeding during sex"<<endl;
	cout<<"5. lower abdominal pain"<<endl;
	cout<<"6.Musle or joint pain"<<endl; 
	cout<<"7.sore throat and fever"<<endl;
	cout<<"8.Anal itching, discharge or bleeding"<<endl;
	cout<<"9.Swollen testicles"<<endl;
	cout<<"10.Rectal pain and discharge"<<endl;    


}
 int main(){
cout<<"Hello! you are highly welcome to our health channel\n";
cout<<" "<<endl;
cout<<"Please this system software is design purposely for CHECKING and TREATING sexually transmitted infections(STIs)\n";
symptoms();
cout<<" "<<endl;
cout<<"Create Account/Login Account\n";
name();
cout<<" "<<endl;
cout<<"Do you see this symptoms\n";
 	list();
 	theo();

 	
 	return 0;
 }
 
